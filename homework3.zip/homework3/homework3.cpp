#include <iostream>
#include <stdexcept>
#include <ctime>
#include "Deck.h"
#include "SidePile.h"

using namespace std;



void updateDecks(Deck& winnerDeck, Deck& loserDeck, int playerCard, int computerCard) 
{
    winnerDeck.enqueue(playerCard);
    winnerDeck.enqueue(computerCard);
}

int main() {
    srand(time(0));

    Deck playerDeck, computerDeck;
    SidePile playerSidePile, computerSidePile;

    int playerDeckInit[] = { 7, 4, 9};
    int computerDeckInit[] = { 1, 2, 3 };
    for (int i = 0; i < 3; ++i) {
        playerDeck.enqueue(playerDeckInit[i]);
        computerDeck.enqueue(computerDeckInit[i]);
    }
    playerSidePile.push(8);
    computerSidePile.push(8);

    int gameStyle;
    cout << "Enter game style (1 for number of rounds, 2 for until out of cards): ";
    cin >> gameStyle;

    int numRounds = (gameStyle == 1) ? 10 : 0;
    int round = 1;

    while ((gameStyle == 1 && round <= numRounds) || (gameStyle == 2 && playerDeck.size() > 0 && computerDeck.size() > 0)) {
        cout << "Round " << round << endl;

        if (playerDeck.size() == 0 && playerSidePile.size() == 0) {
            cout << "Player has no more cards. Computer wins the game!" << endl;
            return 0;
        }
        if (computerDeck.size() == 0 && computerSidePile.size() == 0) {
            cout << "Computer has no more cards. Player wins the game!" << endl;
            return 0;
        }

        int playerMove, computerMove;
        cout << "Enter action for player (1 to push, 2 to pull): ";
        cin >> playerMove;
        computerMove = rand() % 2 + 1;

        int playerCard = (playerDeck.size() > 0) ? playerDeck.dequeue() : 0;
        int computerCard = (computerDeck.size() > 0) ? computerDeck.dequeue() : 0;

        if (playerMove == 1) {
            playerSidePile.push(playerCard);
            playerCard = (playerDeck.size() > 0) ? playerDeck.dequeue() : 0;
        }
        else {
            playerCard += playerSidePile.pop();
        }

        if (computerMove == 1) {
            computerSidePile.push(computerCard);
            computerCard = (computerDeck.size() > 0) ? computerDeck.dequeue() : 0;
        }
        else {
            computerCard += computerSidePile.pop();
        }

        if (playerCard > computerCard) {
            cout << "Player wins the round!" << endl;
            updateDecks(playerDeck, computerDeck, playerCard, computerCard);
        }
        else {
            cout << "Computer wins the round!" << endl;
            updateDecks(computerDeck, playerDeck, playerCard, computerCard);
        }

        round++;
    }

    if (playerDeck.size() > computerDeck.size()) {
        cout << "Player wins the game!" << endl;
    }
    else {
        cout << "Computer wins the game!" << endl;
    }

    return 0;
}