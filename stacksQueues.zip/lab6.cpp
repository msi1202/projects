
#include "stack.h"
#include "queue.h"
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
using namespace std;

string flipping(const string& input) 
{
	queue<string> wQueue(input.length());
	stack<char> stackChar(input.length());
	stringstream ss(input);
	string word;
	while (ss >> word) 
	{
		wQueue.enqueue(new string(word));
	}
	string output = "";
	while (wQueue.length() > 0) 
	{
		string* element = wQueue.dequeue();
		for (char c : *element)
		{
			char* p = new char;
			*p = c;
			stackChar.push(p);
		}
		while (stackChar.length() > 0) 
		{
			output += *stackChar.Top();
			stackChar.pop();
		}
		output += " ";
		delete element;
	}
	output = output.substr(0, output.length() - 1);
	return output;
}

int main()
{
	int option = 0;
	do
	{
		cout << "1. Input taken from file" << endl;
		cout << "2. Input taken from command line" << endl;
		cout << "3. Exit program" << endl;
		cout << "Enter option number: " << endl;
		cin >> option;
		if (option == 1)
		{
			cin.ignore();
			string fileName;
			cout << "Enter file name: " << endl;
			cin >> fileName;
			fstream dataFile;
			dataFile.open(fileName+".txt", ios::in);
			while (dataFile.fail())
			{
				cout << "Error! File Does not exist." << endl;
				cout << "Enter file name: " << endl;
				cin >> fileName;
				fstream dataFile;
				dataFile.open(fileName, ios::in);
			}		
			string line, sentence = "";
			while (getline(dataFile, line)) 
			{
				sentence += line + " ";
			}

			dataFile.close();
			cout << "Text before flipping: " << sentence << endl;
			cout << "Altered text: " << flipping(sentence) << endl;
		}
		else if (option == 2) 
		{
			string s1;
			cin.ignore();
			cout << "Enter string you wish to flip: " << endl;
			getline(cin, s1);
			cout << "Altered text: " << flipping(s1) << endl;
		}
	} while (option!=3);
	return 0;
}

