#include <stdexcept>
using namespace std;

class SidePile {
private:
    int arr[5];
    int top;

public:
    SidePile() : top(-1) {}

    void push(int value) 
    {
        if (top >= 4) throw runtime_error("SidePile is full");
        arr[++top] = value;
    }

    int pop() 
    {
        if (top < 0) throw runtime_error("SidePile is empty");
        return arr[top--];
    }

    int size() const 
    {
        return top + 1;
    }
};

