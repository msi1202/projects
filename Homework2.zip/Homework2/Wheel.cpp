#include "Wheel.h"
#include <ctime>
#include <cstdlib>

//We have used the srand() function to develop a random number for the house's bet and options
Wheel::Wheel() : minValue(1), maxValue(10)
{
    srand(time(0));
}
Wheel::Wheel(int min, int max) : minValue(min), maxValue(max)
{
    srand(time(0));
}
int Wheel::chance()
{
    return minValue + rand() % (maxValue - minValue + 1);
}