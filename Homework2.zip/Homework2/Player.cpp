#include "Player.h"
#include "Wheel.h"
Player::Player(int initialMoney) : money(initialMoney) {}

    void Player::setMoney(int amount) { money = amount; }
    int Player::getMoney() const { return money; }

    int Player::play() {
        return pWheel.chance();
    }

    void Player::changeMoney(int change) {
        money += change;
    }