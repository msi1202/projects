#include "HouseWheel.h"
HouseWheel::HouseWheel() : Wheel() {}

    HouseWheel::HouseWheel(int min, int max) : Wheel(min, max) {}

    int HouseWheel::chance(int playerValue) {
        int result = Wheel::chance();
        return result;
    }

    void HouseWheel::adjustWheelRange(bool houseLost) {
        if (houseLost) {
            maxValue += 10;
        }
        else {
            maxValue -= 5;
            if (maxValue < minValue + 4) {
                maxValue = minValue + 4;
            }
        }
    }