#include <stdexcept>
using namespace std;
struct Node 
{
    int data;
    Node* next;
};

class Deck 
{
private:
    Node* front;
    Node* rear;
    int count;

public:
    Deck() : front(nullptr), rear(nullptr), count(0) {}

    ~Deck() 
    {
        while (front != nullptr) 
        {
            Node* temp = front;
            front = front->next;
            delete temp;
        }
    }

    void enqueue(int value) 
    {
        Node* temp = new Node{ value, nullptr };
        if (rear != nullptr) 
        {
            rear->next = temp;
        }
        else 
        {
            front = temp;
        }
        rear = temp;
        count++;
    }

    int dequeue() {
        if (front == nullptr) throw runtime_error("Deck is empty");
        int value = front->data;
        Node* temp = front;
        front = front->next;
        delete temp;
        if (front == nullptr) rear = nullptr;
        count--;
        return value;
    }

    int size() const {
        return count;
    }
};

