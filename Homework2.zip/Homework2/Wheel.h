#pragma once
class Wheel {
protected:
    int minValue;
    int maxValue;

public:
    Wheel();
    Wheel(int , int);
    int chance();
};

