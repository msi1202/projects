#pragma once
#include "Wheel.h"
class HouseWheel : public Wheel 
{
public:
    HouseWheel();

    HouseWheel(int, int);

    int chance(int);

    void adjustWheelRange(bool);
};
