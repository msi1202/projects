#pragma once
#include <iostream>
using namespace std;

template < class T>
class queue
{
	private:
		T** arrayQueue;
		int rear;
		int front;
		int size;
	public:

		class overflow {};
		class underflow {};

		queue(int);
		void enqueue(T* item);
		T* dequeue();
		int length();
		void makeEmpty();
};

template<class T>
queue<T>::queue(int num)
{
	arrayQueue = new T * [num];
	front = 0;
	rear = -1;
	size = num;
}

template<class T>
void queue<T>::enqueue(T* item)
{
	if (rear == size - 1)
	{
		throw runtime_error("Queue full");
	}
	else if (front == -1 && rear == -1)
	{
		front = 0;
		rear = 0;
		arrayQueue[rear] = item;
	}
	else
		arrayQueue[++rear] = item;
}

template<class T>
T* queue<T>::dequeue()
{
	if (front == -1 && rear == -1)
		throw runtime_error("Queue empty");
	else if (front == rear)
	{
		T* temp = arrayQueue[front];
		front = 0;
		rear = -1;
		return temp;
	}
	else
	{
		return arrayQueue[front++];
	}
}

template<class T>
int queue<T>::length()
{
	return (rear - front + 1);
}

template<class T>
void queue<T>::makeEmpty()
{
	for (int i = 0; i < size; ++i)
	{
		delete arrayQueue[i];
	}
	front = -1;
	rear = -1;
}

class Qoverflow : public exception {
	const char* what() const throw() {
		return "Error! Queue is overflow";
	}
};

class Qunderflow : public exception {
	const char* what() const throw() {
		return "Error! Queue is underflow";
	}
};