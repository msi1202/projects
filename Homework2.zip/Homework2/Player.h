#pragma once
class Player {
    int money;
    Wheel pWheel;

public:
    Player(int initialMoney) : money(initialMoney) {}

    void setMoney(int amount) { money = amount; }
    int getMoney() const { return money; }

    int play() {
        return pWheel.chance();
    }

    void changeMoney(int change) {
        money += change;
    }
}
