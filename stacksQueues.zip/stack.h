#pragma once
#include <iostream>
using namespace std;

// Stack template
template < class T>
class stack
{
private:
	T** arrayStacks;
	int size;
	int top;

public:
	// Constructor
	stack(int);

	class overflow {};
	class underflow {};

	// Stack operations
	void push(T*);
	void pop();
	T* Top();
	int length();
	void makeEmpty();
};

template < class T>
stack<T>::stack(int len)
{
	arrayStacks = new T * [len];
	size = len;
	top = -1;
}

template<class T>
void stack<T>::push(T* value)
{
	if (top == (size - 1))
	{
		throw runtime_error("Stack is overflow");
	}
	else
	{
		arrayStacks[++top] = value;
	}
}

template<class T>
void stack<T>::pop()
{
	if (top == -1)
	{
		throw runtime_error("Stack is underflow");
	}
	else
	{
		delete arrayStacks[top--];
	}
}

template<class T>
T* stack<T>::Top()
{
	if (top == -1)
	{
		throw runtime_error("Stack empty");
	}
	else
	{
		return arrayStacks[top];
	}

}

template<class T>
int stack<T>::length()
{
	return top + 1;
}

template<class T>
void stack<T>::makeEmpty()
{
	for (int i = 0; i < size; ++i)
	{
		delete arrayStacks[i];
	}
	top = -1;
}

class overflow : public exception {
	const char* what() const throw() {
		return "Stack overflow!";
	}
};

class underflow : public exception {
	const char* what() const throw() {
		return "Stack underflow!";
	}
};



