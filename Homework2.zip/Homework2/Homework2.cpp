#include <iostream>
#include <ctime>
#include <cstdlib>
#include "Wheel.h"
#include "Player.h"
#include "HouseWheel.h"

using namespace std;

int main() {
    Player player(1000);  
    HouseWheel houseWheel;

    int option;
    int consecutiveHouseWins = 0;
    bool hard = false;
    cout << "Do you wish to play in hard mode? (1 for yes, 0 for no): " << endl;
    cin >> hard;
    //Following is the menu for the game
    do {
        cout << "Player money: " << player.getMoney() << endl;
        cout << endl << "1. Play" << endl << "2. Quit" << endl << "Enter your choice: " << endl;
        cin >> option;

        if (option == 1) 
        {
            int bet;
            cout << "Enter your bet(min 6, max 20): " << endl;
            cin >> bet;

            if (bet < 6 || bet > 20) 
            {
                cout << "Error! Please enter a bet between 6 and 20." << endl;
                continue;
            }

            int playerValue = player.play();
            cout << "Player's value: " << playerValue << endl;
            //The following code block determines the number of chances for house
            cout << "Do you want to 1. Double, 2. Halve, or 3. Keep the same bet? ";
            int betOption;
            cin >> betOption;
            switch (betOption) {
            case 1:
                bet *= 2;
                break;
            case 2:
                bet /= 2;
                break;
            case 3:
            default:
                break;
            }

            if (betOption == 1)
            {
                bet=bet*2;
            }
            else if(betOption == 2)
            {
                bet=bet/2;
            }

            int houseWins = 0;
            int houseChances = 0;
            if (betOption == 3)
            {
                houseChances=1;
            }
            else if(betOption==2)
            {
                houseChances = 2;
            }
            for (int i = 0; i < houseChances; ++i) {
                int houseValue = houseWheel.chance(playerValue);
                cout << "House's value: " << houseValue << endl;
                if (houseValue >= playerValue) 
                {
                    houseWins++;
                }
            }

            if (betOption == 1) {
                if (houseWins > 0) {
                    player.changeMoney(-bet);
                    cout << "House wins. Player loses " << bet << " money." << endl;
                }
                else {
                    player.changeMoney(bet);
                    cout << "Player wins " << bet << " money!" << endl;
                }
            }
            else if (betOption == 2) {
                if (houseWins == 2) {
                    player.changeMoney(-bet);
                    cout << "House wins. Player loses " << bet << " money." << endl;
                }
                else if (houseWins == 0) {
                    player.changeMoney(bet);
                    cout << "Player wins " << bet << " money!" << endl;
                }
                else {
                    cout << "It's a draw!" << endl;
                }
            }
            else {
                if (houseWins == 1) {
                    player.changeMoney(-bet);
                    cout << "House wins. Player loses " << bet << " money." << endl;
                }
                else {
                    player.changeMoney(bet);
                    cout << "Player wins " << bet << " money!" << endl;
                }
            }

            //The following code block is the implementation of the hard mode
            if (hard) {
                if (houseWins == houseChances) {
                    consecutiveHouseWins++;
                }
                else {
                    consecutiveHouseWins = 0;
                }
                if (consecutiveHouseWins == 2) {
                    houseWheel.adjustWheelRange(false);
                }
                else {
                    houseWheel.adjustWheelRange(true);
                }
            }

        }
        else if (option == 2) {
            cout << "Thanks for playing! Your final money is: " << player.getMoney() << endl;
            break;
        }

    } while (option != 2 && player.getMoney() > 0);

    return 0;
}